create view total_sales_per_month as
select year(`total_per_order`.`created_date`)  AS `year(created_date)`,
       month(`total_per_order`.`created_date`) AS `month(created_date)`,
       count(`total_per_order`.`total`)        AS `total_orders`,
       sum(`total_per_order`.`total`)          AS `total_sales`
from `projectsem2ver5`.`total_per_order`
group by year(`total_per_order`.`created_date`), month(`total_per_order`.`created_date`)
order by year(`total_per_order`.`created_date`), month(`total_per_order`.`created_date`);

