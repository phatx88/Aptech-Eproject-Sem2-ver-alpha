create view total_per_user as
select `projectsem2ver5`.`users`.`id`                AS `id`,
       `projectsem2ver5`.`users`.`name`              AS `name`,
       `projectsem2ver5`.`users`.`email`             AS `email`,
       `projectsem2ver5`.`users`.`email_verified_at` AS `email_verified_at`,
       `projectsem2ver5`.`users`.`created_at`        AS `created_at`,
       `projectsem2ver5`.`users`.`updated_at`        AS `updated_at`,
       `projectsem2ver5`.`users`.`last_login_at`     AS `last_login_at`,
       `projectsem2ver5`.`users`.`mobile`            AS `mobile`,
       `projectsem2ver5`.`users`.`profile_pic`       AS `profile_pic`,
       `projectsem2ver5`.`users`.`provider`          AS `provider`,
       `projectsem2ver5`.`users`.`is_staff`          AS `is_staff`,
       `projectsem2ver5`.`users`.`is_active`         AS `is_active`,
       ifnull(count(`tpo`.`order_id`), 0)            AS `total_ordered`,
       ifnull(sum(`tpo`.`total`), 0)                 AS `amount_spent`
from ((`projectsem2ver5`.`users` left join `projectsem2ver5`.`order` `o` on (`o`.`customer_id` = `projectsem2ver5`.`users`.`id`))
         left join `projectsem2ver5`.`total_per_order` `tpo` on (`o`.`id` = `tpo`.`order_id`))
group by `projectsem2ver5`.`users`.`id`
order by `projectsem2ver5`.`users`.`id`;

-- comment on column total_per_user.is_staff not supported: 0 - customers, 1 -staff

-- comment on column total_per_user.is_active not supported: 0 - inActive, 1 - isActive

