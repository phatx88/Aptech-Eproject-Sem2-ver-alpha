create view total_order_by_regions as
select `p`.`id`                           AS `id`,
       `p`.`name`                         AS `name`,
       `p`.`type`                         AS `type`,
       `p`.`order_count`                  AS `order_count`,
       count(`tpo`.`total`)               AS `total_orders`,
       cast(sum(`tpo`.`total`) as signed) AS `total_sales`
from (`projectsem2ver5`.`province` `p`
         left join `projectsem2ver5`.`total_per_order` `tpo` on (`tpo`.`province_id` = `p`.`id`))
group by `p`.`id`
order by `p`.`id`;

