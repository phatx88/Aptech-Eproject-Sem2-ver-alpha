create view view_product as
select `projectsem2ver5`.`product`.`id`                  AS `id`,
       `projectsem2ver5`.`product`.`barcode`             AS `barcode`,
       `projectsem2ver5`.`product`.`sku`                 AS `sku`,
       `projectsem2ver5`.`product`.`name`                AS `name`,
       `projectsem2ver5`.`product`.`price`               AS `price`,
       `projectsem2ver5`.`product`.`discount_percentage` AS `discount_percentage`,
       `projectsem2ver5`.`product`.`discount_from_date`  AS `discount_from_date`,
       `projectsem2ver5`.`product`.`discount_to_date`    AS `discount_to_date`,
       `projectsem2ver5`.`product`.`featured_image`      AS `featured_image`,
       `projectsem2ver5`.`product`.`inventory_qty`       AS `inventory_qty`,
       `projectsem2ver5`.`product`.`category_id`         AS `category_id`,
       `projectsem2ver5`.`product`.`brand_id`            AS `brand_id`,
       `projectsem2ver5`.`product`.`created_date`        AS `created_date`,
       `projectsem2ver5`.`product`.`description`         AS `description`,
       `projectsem2ver5`.`product`.`star`                AS `star`,
       `projectsem2ver5`.`product`.`featured`            AS `featured`,
       `projectsem2ver5`.`product`.`hidden`              AS `hidden`,
       `projectsem2ver5`.`product`.`view_count`          AS `view_count`,
       `projectsem2ver5`.`product`.`deleted_at`          AS `deleted_at`,
       round(if(`projectsem2ver5`.`product`.`discount_percentage` is null or
                `projectsem2ver5`.`product`.`discount_from_date` > curdate() or
                curdate() > `projectsem2ver5`.`product`.`discount_to_date`, `projectsem2ver5`.`product`.`price`,
                `projectsem2ver5`.`product`.`price` * (1 - `projectsem2ver5`.`product`.`discount_percentage` / 100)),
             2)                                          AS `sale_price`
from `projectsem2ver5`.`product`;

-- comment on column view_product.featured not supported: 1: nổi bật

