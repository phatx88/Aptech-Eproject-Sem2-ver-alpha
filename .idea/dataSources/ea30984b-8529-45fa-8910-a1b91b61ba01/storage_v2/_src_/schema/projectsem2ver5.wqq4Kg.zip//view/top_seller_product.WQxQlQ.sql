create view top_seller_product as
select cast(`projectsem2ver5`.`order_item`.`product_id` as char charset utf8mb4)               AS `product_id`,
       `view_product`.`name`                                                                   AS `name`,
       `view_product`.`inventory_qty`                                                          AS `inventory`,
       cast(`view_product`.`sale_price` as signed)                                             AS `price`,
       cast(sum(`projectsem2ver5`.`order_item`.`qty`) as signed)                               AS `total_qty`,
       cast(`view_product`.`sale_price` * sum(`projectsem2ver5`.`order_item`.`qty`) as signed) AS `total_sales`
from (`projectsem2ver5`.`order_item`
         join `projectsem2ver5`.`view_product` on (`projectsem2ver5`.`order_item`.`product_id` = `view_product`.`id`))
group by `projectsem2ver5`.`order_item`.`product_id`;

