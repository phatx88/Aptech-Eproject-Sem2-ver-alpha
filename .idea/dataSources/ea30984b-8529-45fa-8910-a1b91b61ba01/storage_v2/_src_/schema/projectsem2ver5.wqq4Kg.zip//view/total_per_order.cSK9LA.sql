create view total_per_order as
select `projectsem2ver5`.`order_item`.`order_id`                                               AS `order_id`,
       `o`.`created_date`                                                                      AS `created_date`,
       `p`.`id`                                                                                AS `province_id`,
       `o`.`shipping_fee`                                                                      AS `shipping_fee`,
       ifnull(`c`.`number`, 0)                                                                 AS `discount`,
       `o`.`shipping_fee` - ifnull(`c`.`number`, 0) +
       sum(`projectsem2ver5`.`order_item`.`unit_price` * `projectsem2ver5`.`order_item`.`qty`) AS `total`
from (((((`projectsem2ver5`.`order_item` join `projectsem2ver5`.`order` `o` on (`o`.`id` = `projectsem2ver5`.`order_item`.`order_id`)) left join `projectsem2ver5`.`coupon` `c` on (`o`.`coupon_id` = `c`.`id`)) join `projectsem2ver5`.`ward` `w` on (`o`.`shipping_ward_id` = `w`.`id`)) join `projectsem2ver5`.`district` `d` on (`w`.`district_id` = `d`.`id`))
         join `projectsem2ver5`.`province` `p` on (`d`.`province_id` = `p`.`id`))
where `o`.`order_status_id` = 5
group by `o`.`created_date`
order by `o`.`created_date`;

